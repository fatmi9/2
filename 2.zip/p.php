<?php
system('clear');
$n = "\n";
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);

$ss = "socks5";
$ss = "socks4";
$ss = "http";
//$dc = gt("https://www.proxy-list.download/api/v2/get?l=en&t=".$ss, ["Host: www.proxy-list.download"]);
$dc = gt("https://proxylist.geonode.com/api/proxy-list?protocols=".$ss."&limit=500&page=1&sort_by=lastChecked&sort_type=desc", ["Host: proxylist.geonode.com"]);
$g = 0;
while(true){
	$g++;
	$tt = par('TOTAL": "','"',$dc,1);
	$ip = par('ip":"','"',$dc,$g);
	$p = par('port":"','"',$dc,$g);
	echo $g." \033[1;33m[\033[1;35m".date('H:i:s')."\033[1;33m]\033[0m => \033[1;36m$ip$n";
	if($ip){
		save('http.txt', $ss.'://'.$ip.':'.$p.$n);
		}
	if($ip == false){
		exit;
	}
}


function par($param1,$param2,$res,$num){$one = explode($param1,$res);$two = explode($param2,$one[$num]);return $two[0];}
function save($files, $data){	$file = fopen($files, 'a');				fwrite($file, $data);				fclose($file);}
function gt($url, $hd){
    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => $hd,
    CURLOPT_TIMEOUT => 0,
    ));
    $response = curl_exec($curl);
    $errno = curl_errno($curl);
    if ($errno) {
    return false;
   }
    curl_close($curl);
    return $response;
}